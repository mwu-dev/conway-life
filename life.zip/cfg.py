import pygame

pygame.init()
cellSize = 5
width = 1000
height = 1000
black = (0,0,0)
white = (255,255,255)
screen = pygame.display.set_mode((width, height))